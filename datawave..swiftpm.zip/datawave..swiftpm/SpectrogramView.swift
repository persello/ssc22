import SwiftUI

struct SpectrogramView: View {
    var decoder: MFDecoder
    let backgroundColor: Color
    
    init(decoder: MFDecoder, backgroundColor: Color = .secondary.opacity(0.10)) {
        self.decoder = decoder
        self.backgroundColor = backgroundColor
    }
    
    func indexToFrequency(_ val: Float, numPoints: Int) -> Float {
        return ((val + (Float(MFDecoder.convolutionWindowSize)) / 2) / Float(numPoints)) * (decoder.nyquistFrequency ?? 20000)
    }
    
    func getXCoordinate(_ val: CGFloat, size: CGSize, numPoints: Int) -> CGFloat {
        let frequencyRange = decoder.settings.range
        let minimumFrequency = CGFloat(decoder.settings.lowerLimit - frequencyRange / 8)
        let maximumFrequency = CGFloat(decoder.settings.upperLimit + frequencyRange / 8)
        let extendedRange = maximumFrequency - minimumFrequency
        
        var normalizedValue: CGFloat = 0
        if extendedRange > 0 {
            normalizedValue = (val - minimumFrequency) / extendedRange
        }
        
        return normalizedValue * size.width
    }
    
    func getYCoordinate(_ val: CGFloat, size: CGSize) -> CGFloat {
        return size.height - val
    }
    
    func generatePath(vals: [Float], size: CGSize) -> Path {
        let numPoints = vals.count
        var path = Path()
        
        var firstPoint = true        
        // TODO: Move exponential transform to MFDecoder.
        (0...decoder.frequencyDomainBuffer.count).map({
            (indexToFrequency(Float($0), numPoints: MFDecoder.samplesPerFrame), $0)
        }).filter({
            let lower = decoder.settings.lowerLimit - decoder.settings.range / 8
            let upper = decoder.settings.upperLimit + decoder.settings.range / 8
            return Int($0.0) < upper && Int($0.0) > lower
        }).map({
            CGPoint(
                x: getXCoordinate(CGFloat($0.0), size: size, numPoints: numPoints),
                y: getYCoordinate(CGFloat(decoder.normalizedFrequencyBuffer(index: $0.1)), size: size)
            )
        }).forEach({
            if (firstPoint) {
                path.move(to: $0)
                firstPoint = false
                return
            }
            path.addLine(to: $0)
        })
        
        return path
    }
    
    var body: some View {
        TimelineView(.animation(minimumInterval: 0.1, paused: false), content: { timeline in
            Canvas { context, size in
                // Take the timeline
                let _ = timeline
                
                // Background
                let bg = Path(CGRect(x: 0, y: 0, width: size.width, height: size.height))
                context.fill(bg, with: .color(backgroundColor))
                
                // Threshold line
                let tl = Path(
                    CGRect(
                        x: 0,
                        y: getYCoordinate(
                            CGFloat(decoder.settings.threshold),
                            size: size
                        ),
                        width: size.width,
                        height: 1
                    )
                )
                context.fill(tl, with: .color(.secondary.opacity(0.5)))
                
                // Frequency lines
                for r in decoder.settings.frequencies {
                    for f in r {
                        let fl = Path(
                            CGRect(
                                x: getXCoordinate(CGFloat(f), size: size,
                                                  numPoints: Int((decoder.nyquistFrequency ?? 1))),
                                y: 0,
                                width: 1,
                                height: size.height
                            )
                        )
                        context.fill(fl, with: .color(.secondary.opacity(0.5)))
                    }
                }
                
                // Generate the path
                let chartPath = generatePath(vals: decoder.frequencyDomainBuffer, size: size)
                context.stroke(chartPath, with: .color(.accentColor))
            }
        })
    }
}

struct SpectrogramView_Previews: PreviewProvider {
    static var decoder: MFDecoder = {
        let decoder = MFDecoder(settings: MFSettings())
        Task {
            try await decoder.startCapture()
        }
        return decoder
    }()
    static var previews: some View {
        SpectrogramView(decoder: decoder)
    }
}
