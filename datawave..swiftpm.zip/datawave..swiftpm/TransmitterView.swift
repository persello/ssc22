import SwiftUI

struct TransmitterView: View {
    @State var text: String = ""
    @Binding var settings: MFSettings
    var body: some View {
        VStack {
            TextField("Enter some text to transmit...", text: $text)
                .textFieldStyle(.roundedBorder)
                .padding()
                .toolbar(content: {
                    ToolbarItem(placement: .bottomBar, content: {
                        Button(action: {
                            DispatchQueue.global().async {
                                let encoder = MFEncoder(settings)
                                encoder.playBitArray(bits: BitsUtilities.stringToBits(text),
                                                     completion: {})
                            }
                        }, label: {
                            Label("Send", systemImage: "wave.3.forward")
                        })
                    })
                })
            Spacer()
        }
    }
    
    struct TransmitterView_Previews: PreviewProvider {
        static var previews: some View {
            NavigationView {
                TransmitterView(settings: .constant(MFSettings()))
            }
        }
    }
}
