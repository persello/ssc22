import SwiftUI

struct TestbenchView: View {
    @Binding var settings: MFSettings
    var body: some View {
        HStack {
            ReceiverView(settings: $settings)
            TransmitterView(settings: $settings)
        }
        .navigationTitle("Testbench")
    }
}

struct TestbenchView_Previews: PreviewProvider {
    static var previews: some View {
        TestbenchView(settings: .constant(MFSettings()))
    }
}
