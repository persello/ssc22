import Foundation

struct BitsUtilities {
    static func bitsToString(_ bits: [Bool]) -> String {
        let bytesCount = bits.count.quotientAndRemainder(dividingBy: 8).quotient
        var bytes: [UInt8] = [UInt8].init(repeating: 0, count: bytesCount)
        for i in 0..<bytesCount {
            for bit in 0..<8 {
                bytes[i] += (bits[(8 * i) + bit] ? 1 : 0) << bit
            }
        }
        
        return String(bytes: bytes, encoding: .utf8) ?? ""
    }
    
    static func stringToBits(_ string: String) -> [Bool] {
        let bytes: [UInt8] = Array(string.utf8)
        
        var bits: [Bool] = []
        for byte in bytes {
            for bit in 0...7 {
                bits.append((byte & (1 << bit)) != 0)
            }
        }
        
        return bits
    }
}
