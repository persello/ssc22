import AVFoundation
import Accelerate
import UIKit

public class MFDecoder: NSObject {
    
    // MARK: CONFIGURATION
    var settings: MFSettings
    
    // MARK: CONSTANTS
    
    /// Number of samples for each "frame".
    static internal let samplesPerFrame = 2048
    
    /// The number of samples to shift forward at each frame.
    static internal let deltaBetweenFrames = 256
    
    /// The Hann window that multiplies the signal before each transform.
    static internal let hannWindow = vDSP.window(ofType: Float.self,
                                                 usingSequence: .hanningDenormalized,
                                                 count: samplesPerFrame,
                                                 isHalfWindow: false)
    
    /// The transofrm applied to the signal.
    static internal let forwardDCT = vDSP.DCT(count: samplesPerFrame, transformType: .II)!
    
    // MARK: WORK VARIABLES AND BUFFERS FOR TRANSFORM
    
    /// The highest frequency that can be represented.
    /// Automatically detected at the first capture, based on sampling frequency.
    internal var nyquistFrequency: Float? = nil
    
    /// A buffer that contains the raw data from.
    internal var rawAudioData = [Int16]()
    
    /// Single-precision time-domain values buffer.
    internal var timeDomainBuffer = [Float](repeating: 0, count: samplesPerFrame)
    
    /// Convolution with a rectangular window for moving average.
    static internal let convolutionWindowSize = 4
    
    /// Single-precision frequency-domain values buffer.
    public var frequencyDomainBuffer = [Float](repeating: 0, count: samplesPerFrame - convolutionWindowSize + 1)
    
    // MARK: AVFoundation
    
    /// Is the capture session configured?
    private var configured = false
    
    /// The capture session for the microphone input.
    private let captureSession = AVCaptureSession()
    
    /// The output of the session.
    private let audioOutput = AVCaptureAudioDataOutput()
    
    /// The capture delegate queue.
    private let captureQueue = DispatchQueue(label: "captureQueue",
                                             qos: .userInitiated,
                                             attributes: [],
                                             autoreleaseFrequency: .workItem)
    
    /// MARK: Decoding
    
    internal var decodeTimerStarted = false
    
    /// Handler function that is called each time a new signal is received.
    internal var bitsHandler: (([Bool]) -> Void)?
    
    /// Table that holds the number of times that specific frequency has been found to be over threshold.
    internal var frequenciesHistory: [[Int]] = []
    
    /// The number of times that a frequency has to be found over threshold before considering it as an over-threshold signal.
    static let timeThreshold: Int = 1
    
    /// The period of the decode timer.
    static let timerPeriod: TimeInterval = 0.02
    
    /// Table that holds the current state of the frequencies.
    internal var frequenciesState: [[Bool]] = []
    
    /// The number of silent samples before considering silence.
    static let silenceTimeThreshold: Int = 5
    
    /// The silent samples counter.
    internal var silenceCounter: Int = 0
    
    /// The latest decoded signal. Used for rejecting repetition.
    internal var lastReceivedData: Int = -1
    
    init(settings: MFSettings) {
        self.settings = settings
    }
    
    /// Get the corrected frequency data.
    public func normalizedFrequencyBuffer(index: Int) -> Float {
        if frequencyDomainBuffer.indices.contains(index) {
            return exp(frequencyDomainBuffer[index] / settings.exponentialFactor)
        } else {
            return 0
        }
    }
    
    private func configure() async throws {
        
        // Check for authorization.
        switch AVCaptureDevice.authorizationStatus(for: .audio) {
        case .authorized:
            break
        case .notDetermined:
            let result = await AVCaptureDevice.requestAccess(for: .audio)
            if !result {
                throw MFCaptureError.notAuthorized
            } else {
                try await configure()
            }
        default:
            throw MFCaptureError.notAuthorized
        }
        
        // Configure the microphone.
        captureSession.beginConfiguration()
        
        // Attach output data.
        if captureSession.canAddOutput(audioOutput) {
            captureSession.addOutput(audioOutput)
        } else {
            throw MFCaptureError.configurationError("Unable to add an output to the capture session.")
        }
        
        // Obtain input device.
        guard let microphone = AVCaptureDevice.default(.builtInMicrophone, for: .audio, position: .unspecified),
              let microphoneInput = try? AVCaptureDeviceInput(device: microphone) else {
                  throw MFCaptureError.configurationError("Unable to obtain a microphone input device.")
              }
        
        // Attach input device.
        if captureSession.canAddInput(microphoneInput) {
            captureSession.addInput(microphoneInput)
        } else {
            throw MFCaptureError.configurationError("Unable to add an input to the capture session.")
        }
        
        captureSession.commitConfiguration()
        audioOutput.setSampleBufferDelegate(self, queue: captureQueue)
    }
    
    public func startCapture() async throws {
        if !self.configured {
            try await configure()
            configured = true
        }
        captureSession.startRunning()
    }
    
    public func stopCapture() {
        captureSession.stopRunning()
    }
    
    public func started() -> Self {
        Task {
            try? await self.startCapture()
        }
        return self
    }
    
    public func applySettings(settings: MFSettings) -> Self {
        self.settings = settings
        return self
    }
}
