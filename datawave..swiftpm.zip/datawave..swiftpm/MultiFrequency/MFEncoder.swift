import Foundation
import AVFoundation
import Accelerate

public struct MFEncoder {
    
    static let engine = AVAudioEngine()
    static let player = AVAudioPlayerNode()
    static let format = AVAudioFormat(standardFormatWithSampleRate: 48_000.0, channels: 1)!
    let settings: MFSettings
    
    public init(_ settings: MFSettings) {
        self.settings = settings
    }
    
    public func playBitArray(bits: [Bool], completion: @escaping () -> Void) {
        
        var audioArray: [Int16] = []
        let freqs: [[Int]] = bitsToFrequencies(bits: bits)
        let mixer = Self.engine.mainMixerNode
        let sr = Int(Self.format.sampleRate)
        
        // Generate sound
        for frequencyGroup in freqs {
            audioArray.append(contentsOf:
                                generateTone(freqs: frequencyGroup,
                                             duration: settings.pulseDuration
                                                .converted(to: .seconds).value,
                                             sampleRate: sr))
            audioArray.append(contentsOf: generateTone(freqs: [],
                                                       duration: settings.pauseDuration
                                                        .converted(to: .seconds).value,
                                                       sampleRate: sr))
        }
        
        audioArray.append(contentsOf: [Int16](repeating: 0, count: audioArray.count * 4))
        
        Self.engine.attach(Self.player)
        Self.engine.connect(Self.player,
                            to: mixer,
                            format: Self.format)
        Self.engine.prepare()
        
        do {
            try Self.engine.start()
        } catch {
            print("Error info: \(error)")
        }
        
        if let buffer = AVAudioPCMBuffer(pcmFormat: Self.format, frameCapacity: UInt32(audioArray.count)) {
            
            var floatData = [Float](repeating: 0.0, count: audioArray.count)
            var scale = Float(Int16.max) + 10.0
            vDSP_vflt16(audioArray, 1, &floatData, 1, vDSP_Length(audioArray.count))
            vDSP_vsdiv(floatData, 1, &scale, &floatData, 1, vDSP_Length(audioArray.count))
            
            memcpy(buffer.floatChannelData?[0], floatData, audioArray.count)
            
            buffer.frameLength = AVAudioFrameCount(audioArray.count)
            Self.player.scheduleBuffer(buffer, completionHandler: completion)
        }
        
        Self.player.play()
    }
    
    func incrementArray(array: inout [Int], position: Int, limit: [Int]) {
        guard position < array.count,
              position >= 0 else {
                  return
              }
        
        array[position] += 1
        if(array[position] == limit[position] && position != 0) {
            array[position] = 0
            incrementArray(array: &array, position: position - 1, limit: limit)
        }
    }
    
    func bitsToFrequencies(bits: [Bool]) -> [[Int]] {
        
        // Generate tone map.
        var toneMap: [[Int]] = []
        var currentFreq = [Int](repeating: 0, count: settings.frequencies.count)
        let numberOfFrequencies: [Int] = settings.frequencies.map({ $0.count })
        
        repeat {
            
            if currentFreq.first == numberOfFrequencies.first { break }
            
            toneMap.append([])
            
            // Generate tone map item.
            for f in currentFreq.enumerated() {
                toneMap[toneMap.count - 1].append(settings.frequencies[f.offset][f.element])
            }
            
            // Increment indices.
            incrementArray(array: &currentFreq, position: currentFreq.count - 1, limit: numberOfFrequencies)
        } while true
        
        let bitsPerSignal: Int = Int(settings.dataPerSound.converted(to: .bits).value)
        let signalCount: Int = bits.count.quotientAndRemainder(dividingBy: bitsPerSignal).quotient
        var signals: [Int] = [Int](repeating: 0, count: signalCount)
        
        // Transform bits in integers.
        for i in 0..<signalCount {
            for bit in 0..<bitsPerSignal {
                signals[i] += (bits[i * bitsPerSignal + bit] ? 1 : 0) << bit
            }
        }
        
        // Build tone definitions.
        let tones = signals.map({
            toneMap[$0]
        })
        
        return tones
    }
    
    func generateTone(freqs: [Int], duration: TimeInterval, sampleRate: Int) -> [Int16] {
        var buffer = [Int16](repeating: 0, count: Int(duration * Double(sampleRate)))
        
        guard !freqs.isEmpty else { return buffer }
        
        let singleWaveAmplitude: Float = Float(Int16.max) / Float(freqs.count)
        
        for i in buffer.indices {
            buffer[i] = freqs.reduce(Int16(0), { result, freq in
                result + Int16(sin(2 * Float.pi * Float(freq) * (Float(i) / Float(sampleRate))) * singleWaveAmplitude)
            })
        }
        
        return buffer
    }
}
