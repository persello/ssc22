import Foundation

extension MFDecoder {
    public func startDecoding(onBitsReceived handler: @escaping (_ bits: [Bool]) -> Void) {
        self.bitsHandler = handler
        
        if !self.decodeTimerStarted {
            self.decodeTimerStarted = true
            // DispatchQueue.global(qos: .userInitiated).async {
                Timer.scheduledTimer(withTimeInterval: Self.timerPeriod, repeats: true, block: { _ in
                    self.analyze()
                })
            // }
        }
    }
    
    func analyze() {
        func frequencyToNearestIndex(frequency: Float, numVals: Int) -> Int {
            return Int((frequency * Float(numVals) / Float(nyquistFrequency ?? 20000)) - (Float(MFDecoder.convolutionWindowSize) / 2))
        }
        
        // Convert frequencies to array indexes.
        let indexes: [[Int]] = settings.frequencies.map({ row in
            row.map({ val in
                frequencyToNearestIndex(frequency: Float(val), numVals: frequencyDomainBuffer.count)
            })
        })
        
        // print("indexes: \(indexes)")
        
        // Prepare destination arrays.
        if frequenciesHistory.count != settings.frequencies.count {
            frequenciesHistory.removeAll()
            frequenciesState.removeAll()
            for row in indexes {
                frequenciesHistory.append([Int](repeating: 0, count: row.count))
                frequenciesState.append([Bool](repeating: false, count: row.count))
            }
        }
        
        // Check value threshold.
        for row in indexes.enumerated() {
            for i in row.element.enumerated() {
                if self.normalizedFrequencyBuffer(index: i.element) > settings.threshold {
                    frequenciesHistory[row.offset][i.offset] += 1
                } else {
                    frequenciesHistory[row.offset][i.offset] = 0
                }
            }
        }
        
        // print("frequencies history: \(frequenciesHistory)")
        
        // Check time threshold.
        frequenciesState = frequenciesHistory.map({ row in
            row.map({ history in
                history > Self.timeThreshold
            })
        })
        
        // print("frequencies state: \(frequenciesState)")
        
        let bitArray: [Bool] = decode(data: frequenciesState)
        
        self.bitsHandler?(bitArray)
    }
    
    /// Decodes a change matrix into a sequence of bits.
    func decode(data: [[Bool]]) -> [Bool] {
        
        var activeIndices: [(Int, Int)] = []
        for row in data.enumerated() {
            for val in row.element.enumerated() {
                if val.element == true {
                    activeIndices.append((row.offset, val.offset))
                }
            }
        }
        
        if activeIndices.isEmpty { 
            self.silenceCounter += 1
            if self.silenceCounter > Self.silenceTimeThreshold {
                self.lastReceivedData = -1
            }
        }
        
        guard let value = indicesToValue(activeIndices: activeIndices, frequencyMatrix: data as [[Any]]) else {
            return []
        }
        
        guard value != lastReceivedData else { return [] }
        
        lastReceivedData = value
        
        var result: [Bool] = []
        for index in 0..<Int(settings.dataPerSound.converted(to: .bits).value) {
            result.append((value & 1 << index) != 0 ? true : false)
        }
        
        return result
    }
    
    func indicesToValue(activeIndices: [(Int, Int)], frequencyMatrix: [[Any]]) -> Int? {
        // Check that the active indices are one per row.
        let distributed = activeIndices.map({ $0.0 })
            .sorted()
            .enumerated()
            .allSatisfy({
                $0.element == $0.offset
            })
        
        // Check that active indices are the same number as the rows in the frequency matrix.
        // Also check the previous condition.
        guard distributed && activeIndices.count == frequencyMatrix.count else {
            return nil
        }
        
        // Calculate the digits' weights.
        let numberOfDigits: [Int] = frequencyMatrix.map({$0.count})
        let digitsPower: [Int] = numberOfDigits.enumerated().map({
            // The product of the count of all the less-significant digits.
            numberOfDigits[($0.offset + 1)...].reduce(1, {
                $0 * $1
            })
        })
        
        // Compute the value.
        // result += index * index's value (product of all the less-significant digits)
        let result: Int = activeIndices.enumerated().reduce(0, {
            $0 + ($1.element.1 * digitsPower[$1.offset])
        })
        
        return result
    }
}
