import Foundation

public enum MFCaptureError: Error, Equatable {
    case notAuthorized
    case configurationError(String)
}

extension MFCaptureError: CustomStringConvertible {
    public var description: String {
        switch self {
        case .notAuthorized:
            return "Authorization Error"
        case .configurationError:
            return "Configuration Error"
        }
    }
}

extension MFCaptureError: LocalizedError {
    public var errorDescription: String? {
        switch self {
        case .notAuthorized:
            return "Unable to access the microphone."
        case .configurationError(_):
            return "An error occurred during the configuration of the capture device."
        }
    }
    
    public var failureReason: String? {
        switch self {
        case .notAuthorized:
            return "The user denied access to the microphone."
        case .configurationError(let reason):
            return reason
        }
    }
    
    public var recoverySuggestion: String? {
        switch self {
        case .notAuthorized:
            return "Open the app's settings and re-enable microphone access."
        default:
            return nil
        }
    }
}
