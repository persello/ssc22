import Foundation

public struct MFSettings {
    
    static var shared = Self()
    
    var frequencies: [[Int]] = [[697, 770, 852, 941], [1209, 1336, 1477, 1633]]
    var threshold: Float = 50
    var exponentialFactor: Float = 3.5
    var pulseDuration: Measurement<UnitDuration> = .init(value: 200, unit: .milliseconds)
    var pauseDuration: Measurement<UnitDuration> = .init(value: 100, unit: .milliseconds)
    
    func validate() -> Bool {
        guard combinations > 1,
              threshold > 0,
              exponentialFactor >= 1,
              pulseDuration.converted(to: .milliseconds).value >= 100,
              pauseDuration.converted(to: .milliseconds).value >= 0,
              lowerLimit < upperLimit,
              upperLimit <= 20_000 else {
                  return false
              }
        return true
    }
    
    var combinations: Int {
        return frequencies.reduce(1, {
            $0 * $1.count
        })
    }
    
    var base2combinations: Int {
        var result: Int = 1
        while result < combinations {
            result *= 2
        }
        return result
    }
    
    var dataPerSound: Measurement<UnitInformationStorage> {
        return Measurement<UnitInformationStorage>.init(value: log2(Double(base2combinations)), unit: .bits)
    }
    
    var dataRate: Float {
        let period = pulseDuration.converted(to: .seconds).value + pauseDuration.converted(to: .seconds).value
        return Float(dataPerSound.converted(to: .bits).value) / Float(period)
    }
    
    var lowerLimit: Int {
        if combinations <= 1 { return 0 }
        return frequencies.reduce(Int.max, {
            return min($0, $1.min() ?? 0)
        })
    }
    
    var upperLimit: Int {
        if combinations <= 1 { return 0 }
        return frequencies.reduce(0, {
            return max($0, $1.max() ?? 0)
        })
    }
    
    var range: Int {
        return upperLimit - lowerLimit
    }
}
