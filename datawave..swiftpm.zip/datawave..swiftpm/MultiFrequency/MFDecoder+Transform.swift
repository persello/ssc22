import SwiftUI
import Accelerate

extension MFDecoder {
    /// Transforms the passed array of 16-bit integers into a frequency-domain representation.
    /// The transformed value is stored in the `frequencyDomainBuffer`.
    internal func transform(data: [Int16]) {
        
        // Internal frequency buffer.
        var fbuf = [Float](repeating: 0, count: Self.samplesPerFrame)
        
        // Convert to single-precision.
        vDSP.convertElements(of: data, to: &timeDomainBuffer)
        
        // Apply Hann window.
        vDSP.multiply(timeDomainBuffer, Self.hannWindow, result: &timeDomainBuffer)
        
        // Transform.
        Self.forwardDCT.transform(timeDomainBuffer, result: &fbuf)
        
        // Absolute value.
        vDSP.absolute(fbuf, result: &fbuf)
        
        // To Decibels.
        vDSP.convert(amplitude: fbuf,
                     toDecibels: &fbuf,
                     zeroReference: Float(Self.samplesPerFrame))
        
        // Moving average
        vDSP.convolve(fbuf,
                      withKernel: [Float](repeating: 1 / Float(MFDecoder.convolutionWindowSize), count: MFDecoder.convolutionWindowSize),
                      result: &frequencyDomainBuffer)
    }
}
