import AVFoundation
import Accelerate

extension MFDecoder: AVCaptureAudioDataOutputSampleBufferDelegate {
    public func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        
        var audioBufferList = AudioBufferList()
        var blockBuffer: CMBlockBuffer?
        
        CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(
            sampleBuffer,
            bufferListSizeNeededOut: nil,
            bufferListOut: &audioBufferList,
            bufferListSize: MemoryLayout.stride(ofValue: audioBufferList),
            blockBufferAllocator: nil,
            blockBufferMemoryAllocator: nil,
            flags: kCMSampleBufferFlag_AudioBufferList_Assure16ByteAlignment,
            blockBufferOut: &blockBuffer
        )
        
        guard let data = audioBufferList.mBuffers.mData else {
            return
        }
        
        // Compute the Nyquist frequency, if it hasn't already been done.
        if self.nyquistFrequency == nil {
            let duration = Float(CMSampleBufferGetDuration(sampleBuffer).value)
            let timeScale = Float(CMSampleBufferGetDuration(sampleBuffer).timescale)
            let sampleCount = Float(CMSampleBufferGetNumSamples(sampleBuffer))
            self.nyquistFrequency = 0.5 / (duration / timeScale / sampleCount)
        }
        
        // Fill the buffer more than 2x the samples per frame, if possible...
        if self.rawAudioData.count < Self.samplesPerFrame * 2 {
            let actualSampleCount = CMSampleBufferGetNumSamples(sampleBuffer)
            
            let ptr = data.bindMemory(to: Int16.self, capacity: actualSampleCount)
            let buf = UnsafeBufferPointer(start: ptr, count: actualSampleCount)
            
            rawAudioData.append(contentsOf: Array(buf))
        }
        
        // When at least one frame is ready...
        while self.rawAudioData.count >= Self.samplesPerFrame {
            let dataToProcess = Array(self.rawAudioData[0 ..< Self.samplesPerFrame])
            self.rawAudioData.removeFirst(Self.deltaBetweenFrames)
            self.transform(data: dataToProcess)
        }
    }
}
