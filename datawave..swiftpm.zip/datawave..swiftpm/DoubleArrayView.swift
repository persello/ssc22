import SwiftUI

struct ProminentMenuStyle: MenuStyle {
    func makeBody(configuration: Configuration) -> some View {
        Menu(configuration)
            .padding(8)
            .background(content: { 
                Color.accentColor
            })
            .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
            .foregroundColor(.white)
    }
}

struct DoubleArrayView: View {
    @Binding var data: [[Int]]
    
    @State var editing: Bool = false
    @State var editingNew: Bool = false
    @State var editingIndex: (Int, Int) = (0, 0)
    
    func removeItem(index: (Int, Int)) {
        data[index.0].remove(at: index.1)
        if data[index.0].isEmpty { data.remove(at: index.0) }
    }
    
    func startEditing(at index: (Int, Int)) {
        editingNew = false
        editingIndex = index
        editing = true
    }
    
    func startEditing(newItemAt row: Int) {
        editingNew = true
        editingIndex = (row, 0)
        editing = true
    }
    
    var body: some View {
        Group {
            ForEach(Array(zip(data.indices, data)), id: \.0) { row in
                ScrollView(.horizontal, showsIndicators: false, content: {
                    HStack {
                        ForEach(Array(zip(row.1.indices, row.1)), id: \.0) { val in
                            Menu("\(val.1)") {
                                Text("\(val.1) Hz")
                                
                                Button(action: {
                                    startEditing(at: (row.0, val.0))
                                }, label: {
                                    Label("Edit", systemImage: "pencil")
                                })
                                
                                Button(
                                    role: .destructive,
                                    action: {
                                        removeItem(index: (row.0, val.0))
                                    }, label: {
                                        Label("Remove", systemImage: "trash")
                                    })
                            }
                            .menuStyle(ProminentMenuStyle())
                        }
                        
                        Button(action: {
                            startEditing(newItemAt: row.0)
                        }, label: {
                            Label("Add", systemImage: "plus.circle")
                        })
                            .padding(.horizontal, 4)
                            .labelStyle(.iconOnly)
                    }
                    .padding(.horizontal)
                })
            }
            .listRowInsets(EdgeInsets())
            Button("Add row...", action: {
                data.append([])
                startEditing(newItemAt: data.count - 1)
            })
        }
        .sheet(isPresented: $editing) { 
            DoubleArrayEditView(
                data: $data,
                new: editingNew,
                index: editingIndex,
                editing: $editing
            )
        }
    }
}

//struct DoubleArrayView_Previews: PreviewProvider {
//    static var data = [[1200, 1234, 1321], [43, 12, 455, 17], [2000, 1264]]
//    static var previews: some View {
//        NavigationView {
//            List {
//                DoubleArrayView(data: .constant(data))
//            }
//            .navigationTitle("Double Array")
//        }
//    }
//}
