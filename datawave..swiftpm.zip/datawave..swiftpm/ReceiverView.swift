import SwiftUI

struct ReceiverView: View {
    @State var error: MFCaptureError?
    @State var errorShown: Bool = false
    @Binding var settings: MFSettings
    @State var bits: [Bool] = []
    let decoder: MFDecoder = MFDecoder(settings: MFSettings())
    @State var running: Bool = false {
        didSet {
            if running {
                Task {
                    do {
                        try await decoder.startCapture()
                    } catch let err as MFCaptureError {
                        DispatchQueue.main.async {
                            self.error = err
                            self.errorShown = true
                            self.running = false
                        }
                    }
                }
            } else {
                decoder.stopCapture()
            }
        }
    }
    
    var body: some View {
        VStack {
            SpectrogramView(decoder: decoder.applySettings(settings: settings))
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .onAppear {
                    running = true
                    decoder.startDecoding(onBitsReceived: { vals in
                        if !vals.isEmpty {
                            bits.append(contentsOf: vals)
                        }
                    })
                }
            ScrollView {
                Text(BitsUtilities.bitsToString(bits))
                    .font(.body.monospaced())
                    .foregroundColor(.secondary)
                    .frame(alignment: .topLeading)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            .padding()
        }
        .padding()
        .toolbar(content: {
            ToolbarItem(
                placement: .bottomBar,
                content: {
                    Button(action: {
                        bits = []
                    }, label: {
                        Label("Clear", systemImage: "trash")
                    })
                }
            )
            ToolbarItem(
                placement: .status,
                content: { Text("\(bits.count) bits") }
            )
            ToolbarItem(
                placement: .bottomBar,
                content: {
                    Button(action: {
                        running.toggle()
                    }, label: {
                        Label("Run", systemImage: running ? "pause" : "play")
                    })
                }
            )
        })
        .alert(
            isPresented: $errorShown,
            error: error,
            actions: { error in 
                if error == .notAuthorized {
                    Button("Open Settings") {
                        guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
                            return
                        }
                        
                        if UIApplication.shared.canOpenURL(settingsUrl) {
                            Task {
                                await UIApplication.shared.open(settingsUrl)
                            }
                        }
                    }
                }
            },
            message: { error in
                Text("\(error.failureReason ?? "Unknown reason")\(error.recoverySuggestion == nil ? "" : "\n\n\(error.recoverySuggestion!)")")
            })
    }
}

struct ReceiverView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ReceiverView(settings: .constant(MFSettings()))
        }
    }
}
