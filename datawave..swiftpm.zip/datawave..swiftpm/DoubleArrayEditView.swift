import SwiftUI

struct DoubleArrayEditView: View {
    @Binding var data: [[Int]]
    var new: Bool
    var index: (Int, Int)
    @Binding var editing: Bool
    
    @State var value: Float = 1000
    
    var body: some View {
        NavigationView {
            List {
                Slider(value: $value, in: 20...20000)
                Stepper("Fine control", onIncrement: {
                    value += 10
                    if value > 20000 { value = 20000 }
                }, onDecrement: {
                    value -= 10
                    if value < 20 { value = 20 }
                })
                Text("Frequency: \(Int(value)) Hz")
                    .foregroundColor(.secondary)
            }
            .navigationTitle(new ? "New value" : "Edit value")
            .navigationBarTitleDisplayMode(.inline)
            .interactiveDismissDisabled()
            .toolbar(content: {
                ToolbarItem(placement: .primaryAction, content: {
                    Button("Done") {
                        editing = false
                        if new {
                            data[index.0].append(Int(value))
                        } else {
                            data[index.0][index.1] = Int(value)
                        }
                    }
                    .font(.body.bold())
                    .disabled(value == 0)
                })
            })
            .onAppear(perform: {
                if !new {
                    value = Float(data[index.0][index.1])
                }
            })
        }
        .navigationViewStyle(.stack)
    }
}

struct DoubleArrayEditView_Previews: PreviewProvider {
    static var previews: some View {
        DoubleArrayEditView(
            data: .constant([[1, 2, 3, 4], [10, 11, 12, 13]]),
            new: false,
            index: (1, 3),
            editing: .constant(true)
        )
    }
}
