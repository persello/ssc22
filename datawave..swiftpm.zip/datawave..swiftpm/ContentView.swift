import SwiftUI

struct ContentView: View {
    enum Page {
        case receiver
        case transmitter
        case testBench
        case settings
    }
    
    @State var selectedPage: Page? = .testBench
    @State var previousSelectedPage: Page? = .testBench
    @State var settingsPresentable: Bool = false
    @State var settings: MFSettings = MFSettings()
    
    var body: some View {
        NavigationView {
            List {
                NavigationLink(
                    destination: ReceiverView(settings: $settings).navigationTitle("Receiver"),
                    tag: Page.receiver,
                    selection: $selectedPage,
                    label: {
                        Label("Receiver", systemImage: "wave.3.backward")
                    }
                )
                
                NavigationLink(
                    destination: TransmitterView(settings: $settings).navigationTitle("Transmitter"),
                    tag: Page.transmitter,
                    selection: $selectedPage,
                    label: {
                        Label("Transmitter", systemImage: "wave.3.forward")
                    }
                )
                
                NavigationLink(
                    destination: TestbenchView(settings: $settings).navigationTitle("Testbench"),
                    tag: Page.testBench,
                    selection: $selectedPage,
                    label: {
                        Label("Test bench", systemImage: "arrow.left.arrow.right")
                    }
                )
                
                Button(action: {
                    previousSelectedPage = selectedPage
                    selectedPage = .settings
                    settingsPresentable = true
                }, label: {
                    Label("Settings", systemImage: "gear")
                })
                    .sheet(
                        isPresented: .constant(selectedPage == .settings && settingsPresentable), 
                        onDismiss: {
                            selectedPage = previousSelectedPage
                        },
                        content: {
                            NavigationView {
                                SettingsView(settings: $settings, presented: $settingsPresentable)
                            }
                            .interactiveDismissDisabled()
                        }
                    )
            }
            .listStyle(.sidebar)
            .navigationTitle("datawave.")
        }
    }
}
