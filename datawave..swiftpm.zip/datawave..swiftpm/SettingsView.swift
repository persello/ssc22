import SwiftUI

struct SettingsView: View {
    @Binding var settings: MFSettings
    @Binding var presented: Bool
    let decoder = MFDecoder(settings: MFSettings()).started()
    var body: some View {
        VStack {
            List {
                Section(header: Text("Frequencies")) {
                    DoubleArrayView(data: $settings.frequencies)
                }
                Section(header: Text("Timing parameters")) {
                    Slider(
                        value: $settings.pulseDuration.value,
                        in: 0...1000,
                        step: 5
                    ) {
                        Text("Pulse duration")
                    } minimumValueLabel: {
                        Text("0")
                    } maximumValueLabel: {
                        Text("1 s")
                    }
                    Text("Pulse duration: \(settings.pulseDuration.converted(to: .milliseconds).formatted())")
                        .foregroundStyle(.secondary)
                
                    Slider(
                        value: $settings.pauseDuration.value,
                        in: 0...1000,
                        step: 5
                    ) {
                        Text("Pause duration")
                    } minimumValueLabel: {
                        Text("0")
                    } maximumValueLabel: {
                        Text("1 s")
                    }
                    Text("Pause duration: \(settings.pauseDuration.converted(to: .milliseconds).formatted())")
                        .foregroundStyle(.secondary)
                }
                Section(header: Text("Analysis parameters")) {
                    SpectrogramView(
                        decoder: decoder.applySettings(settings: settings),
                        backgroundColor: .clear
                    )
                        .aspectRatio(1.6, contentMode: .fill)
                        .listRowInsets(EdgeInsets())
                    Slider(
                        value: $settings.exponentialFactor,
                        in: 2...20
                    ) {
                        Text("Exponential factor")
                    } minimumValueLabel: {
                        Text("2")
                    } maximumValueLabel: {
                        Text("20")
                    }
                    Text("Exponential factor: \(settings.exponentialFactor, specifier: "%.2f")")
                        .foregroundStyle(.secondary)
                
                    Slider(
                        value: $settings.threshold,
                        in: 0...200
                    ) {
                        Text("Threshold")
                    } minimumValueLabel: {
                        Text("0")
                    } maximumValueLabel: {
                        Text("200")
                    }
                    Text("Threshold: \(settings.threshold, specifier: "%.0f")")
                        .foregroundStyle(.secondary)
                }
            }
        }
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("Done", action: {
                    presented = false
                })
                    .font(.body.bold())
                    .disabled(!settings.validate())
            }
            ToolbarItem(placement: .primaryAction) {
                Button("Reset", action: { settings = MFSettings() })
            }
            ToolbarItem(placement: .bottomBar, content: {
                HStack {
                    Text("\(settings.validate() ? "Valid" : "Invalid"), speed: \(settings.dataRate, specifier: "%.2f") bps")
                }
            })
        }
            .navigationTitle("Settings")
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView(settings: .constant(MFSettings()), presented: .constant(true))
    }
}
